public class Person {
    String gender = "male";
    String name = "Ivan";
    int weight = 85;
    int age = 25;

    void go() {
        System.out.println("Идти");
    }

    void sit() {
        System.out.println("Сидеть");
    }

    void run() {
        System.out.println("Бежать");
    }

    void speak() {
        System.out.println("Говорить");
    }

    void learnJava() {
        System.out.println("Учим Java!");
    }
}